﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace ToolBoxAdmin
{
    public partial class Form1 : Form
    {
        Thread nt;
        int f = 0;
        public Form1()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panelLogin.Location = new Point(this.Size.Width / 2 - panelLogin.Size.Width / 2, this.Size.Height / 2 - panelLogin.Size.Height / 2);
            panelLogin.Anchor = AnchorStyles.None;
        }

        private void bLogin_Click(object sender, EventArgs e)
        {
            try
            {
                    if (textBoxUser.Text == "admin@toolbox.com" && textBoxSenha.Text== "admin")
                    {
                            this.Close();
                            nt = new Thread(Form2New);
                            nt.SetApartmentState(ApartmentState.STA);
                            nt.Start();
                    }
                    else
                    MessageBox.Show("Falha no Login\nErro ");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha no Login\nErro: " + ex.Message + "\n" + ex.ToString());
            }
        }

        private void Form2New()
        {
            Application.Run(new Form2());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (f == 0)
            {
                textBoxSenha.PasswordChar = char.Parse("\0");
                f = 1;
                button1.BackColor = Color.Gainsboro;
            }
            else
            {
                textBoxSenha.PasswordChar = char.Parse("•");
                f = 0;
                button1.BackColor = Color.Transparent;
            }
        }

        private void textBoxUser_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBoxSenha.Focus();
            }
        }

        private void textBoxSenha_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                bLogin_Click(sender, e);
            }
        }

        GraphicsPath GetRoundPath(RectangleF Rect, int radius)
        {
            float r2 = radius / 2f;
            GraphicsPath GraphPath = new GraphicsPath();

            GraphPath.AddArc(Rect.X, Rect.Y, radius, radius, 180, 90);
            GraphPath.AddLine(Rect.X + r2, Rect.Y, Rect.Width - r2, Rect.Y);
            GraphPath.AddArc(Rect.X + Rect.Width - radius, Rect.Y, radius, radius, 270, 90);
            GraphPath.AddLine(Rect.Width, Rect.Y + r2, Rect.Width, Rect.Height - r2);
            GraphPath.AddArc(Rect.X + Rect.Width - radius,
                             Rect.Y + Rect.Height - radius, radius, radius, 0, 90);
            GraphPath.AddLine(Rect.Width - r2, Rect.Height, Rect.X + r2, Rect.Height);
            GraphPath.AddArc(Rect.X, Rect.Y + Rect.Height - radius, radius, radius, 90, 90);
            GraphPath.AddLine(Rect.X, Rect.Height - r2, Rect.X, Rect.Y + r2);

            GraphPath.CloseFigure();
            return GraphPath;
        }

        private void panelLogin_Paint(object sender, PaintEventArgs e)
        {
            base.OnPaint(e);
            RectangleF Rect = new RectangleF(0, 0, panelLogin.Width, panelLogin.Height);
            GraphicsPath GraphPath = GetRoundPath(Rect, 30);

            panelLogin.Region = new Region(GraphPath);
            using (System.Drawing.Pen pen = new System.Drawing.Pen(System.Drawing.Color.Transparent, 1.75f))
            {
                pen.Alignment = PenAlignment.Inset;
                e.Graphics.DrawPath(pen, GraphPath);
            }
        }

        private void bLogin_Paint(object sender, PaintEventArgs e)
        {
            base.OnPaint(e);
            RectangleF Rect = new RectangleF(0, 0, bLogin.Width, bLogin.Height);
            GraphicsPath GraphPath = GetRoundPath(Rect, 10);

            bLogin.Region = new Region(GraphPath);
            using (System.Drawing.Pen pen = new System.Drawing.Pen(System.Drawing.Color.Transparent, 1.75f))
            {
                pen.Alignment = PenAlignment.Inset;
                e.Graphics.DrawPath(pen, GraphPath);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            System.Diagnostics.Process.Start("http://toolboxservico.space/admin");
        }

        private void button4_Click(object sender, EventArgs e)
        {

            System.Diagnostics.Process.Start("https://toolboxservico.space");
        }
    }
}
