﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;

namespace ToolBoxAdmin
{
    public partial class Form1 : Form
    {
        Thread nt;
        int f = 0;
        public Form1()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panelLogin.Location = new Point(this.Size.Width / 2 - panelLogin.Size.Width / 2, this.Size.Height / 2 - panelLogin.Size.Height / 2);
            panelLogin.Anchor = AnchorStyles.None;
        }

        private void bLogin_Click(object sender, EventArgs e)
        {
            try
            {
                    if (textBoxUser.Text == "admin@toolbox.com" && textBoxSenha.Text== "admin")
                    {
                            this.Close();
                            nt = new Thread(Form2New);
                            nt.SetApartmentState(ApartmentState.STA);
                            nt.Start();
                    }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha no Login\nErro: " + ex.Message + "\n" + ex.ToString());
            }
        }

        private void Form2New()
        {
            Application.Run(new Form2());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (f == 0)
            {
                textBoxSenha.PasswordChar = char.Parse("\0");
                f = 1;
                button1.BackColor = Color.Gainsboro;
            }
            else
            {
                textBoxSenha.PasswordChar = char.Parse("•");
                f = 0;
                button1.BackColor = Color.Transparent;
            }
        }

        private void textBoxUser_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                textBoxSenha.Focus();
            }
        }

        private void textBoxSenha_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                bLogin_Click(sender, e);
            }
        }
    }
}
