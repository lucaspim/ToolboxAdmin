﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Threading;

namespace ToolBoxAdmin
{
    public partial class Form4 : Form
    {
        MySqlConnection con;
        Thread nt;
        int idcategor;

        public Form4()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            try
            {
                con = new MySqlConnection("server=143.106.241.3;port=3306;UserID=cl19248;database=cl19248;password=cl19248");
            }
            catch
            {
                MessageBox.Show("Falha na conexão");
            }
        }

        #region buttons home
        private void bHome_Click(object sender, EventArgs e)
        {
            if (panelBgeral.Visible == false)
            {
                this.bHome.BackColor = System.Drawing.Color.AliceBlue;
                panelBgeral.Visible = true;
            }
            else
            {
                this.bHome.BackColor = System.Drawing.Color.White;
                panelBgeral.Visible = false;
            }
        }

        private void bpedidos_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Sugestao);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bCadastrarServico_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Home);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bServicos_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Servicos);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bOrcamento_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(CadastrarServico);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bSair_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Sair);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void Sair()
        {
            Application.Run(new Form1());
        }

        private void CadastrarServico()
        {
            Application.Run(new Form4());
        }

        private void Servicos()
        {
            Application.Run(new Form3());
        }

        private void Home()
        {
            Application.Run(new Form2());
        }

        private void Sugestao()
        {
            Application.Run(new Form5());
        }
        #endregion

        private void Form4_Load(object sender, EventArgs e)
        {
            panelBgeral.Visible = false;
            try
            {
                con.Open();
                MySqlCommand buscar_servico = new MySqlCommand("Select descategory from tb_categories order by descategory ASC;", con);
                MySqlDataReader resultado = buscar_servico.ExecuteReader();

                while (resultado.Read())
                {
                    comboBoxServico.Items.Add(resultado["descategory"].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            con.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (comboBoxServico.SelectedItem == null && comboBoxServico.SelectedItem == null && richTextBoxNomeServ.Text == null || richTextBoxNomeServ.Text.Length > 256)
                MessageBox.Show("Não foi possível cadastrar devido a falta de dados, por favor certifique-se de selecionar a categoria como, também, digitar uma descrição de no máximo 256 caracteres.\nDescrição possui " + richTextBoxNomeServ.Text.Length + " caracteres.");
            else
            {
                try
                {
                    con.Open();
                    MySqlCommand IdcategorySearch = new MySqlCommand("Select idcategory from tb_categories where descategory = '" + comboBoxServico.SelectedItem.ToString() + "';", con);
                    MySqlDataReader resultado = IdcategorySearch.ExecuteReader();

                    if(resultado.Read())
                    {
                        idcategor = int.Parse(resultado["idcategory"].ToString());
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                con.Close();

                try
                {
                    con.Open();
                    MySqlCommand inserirservico = new MySqlCommand("insert into tb_services(desservice, idcategory) values('" + richTextBoxNomeServ.Text + "','" + idcategor + "');", con);
                    inserirservico.ExecuteNonQuery();

                    MessageBox.Show("Serviço cadastrado");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                con.Close();
            }
        }
    }
}
