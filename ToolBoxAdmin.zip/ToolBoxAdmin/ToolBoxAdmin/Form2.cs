﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;
using System.Threading;

namespace ToolBoxAdmin
{
    public partial class Form2 : Form
    {
        MySqlConnection con;
        Thread nt;
        public Form2()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            try
            {
                con = new MySqlConnection("server=143.106.241.3;port=3306;UserID=cl19248;database=cl19248;password=cl19248");
            }
            catch
            {
                MessageBox.Show("Falha na conexão");
            }
        }

        #region buttons home
        private void bHome_Click(object sender, EventArgs e)
        {
            if (panelBgeral.Visible == false)
            {
                this.bHome.BackColor = System.Drawing.Color.AliceBlue;
                panelBgeral.Visible = true;
            }
            else
            {
                this.bHome.BackColor = System.Drawing.Color.White;
                panelBgeral.Visible = false;
            }
        }

        private void bpedidos_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Sugestao);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void Sugestao()
        {
            Application.Run(new Form5());
        }

        private void bCadastrarServico_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Home);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void Home()
        {
            Application.Run(new Form2());
        }

        private void bServicos_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Servicos);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void Servicos()
        {
            Application.Run(new Form3());
        }

        private void bOrcamento_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(CadastrarServico);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void CadastrarServico()
        {
            Application.Run(new Form4());
        }

        private void bSair_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Sair);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void Sair()
        {
            Application.Run(new Form1());
        }
        #endregion

        private void Form2_Load(object sender, EventArgs e)
        {
            panelBgeral.Visible = false;

            #region Geral labels
            try
            {
                con.Open();
                MySqlCommand Count = new MySqlCommand("select COUNT(idcategory) as id from tb_categories;", con);
                MySqlDataReader resultado = Count.ExecuteReader();

                if (resultado.Read())
                {
                    label8.Text = resultado["id"].ToString() + " Categorias";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            con.Close();

            try
            {
                con.Open();
                MySqlCommand Count = new MySqlCommand("select COUNT(idservice) as id from tb_services;", con);
                MySqlDataReader resultado = Count.ExecuteReader();

                if (resultado.Read())
                {
                    label7.Text = resultado["id"].ToString() + " Serviços";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            con.Close();

            try
            {
                con.Open();
                MySqlCommand Count = new MySqlCommand("select COUNT(idprovider) as id from tb_userprovider;", con);
                MySqlDataReader resultado = Count.ExecuteReader();

                if (resultado.Read())
                {
                    label5.Text = resultado["id"].ToString() + " Prestadores";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            con.Close();

            try
            {
                con.Open();
                MySqlCommand Count = new MySqlCommand("select COUNT(iduser) as id from tb_users;", con);
                MySqlDataReader resultado = Count.ExecuteReader();

                if (resultado.Read())
                {
                    label9.Text = resultado["id"].ToString() + " Clientes";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            con.Close();
            #endregion
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.linkLabel1.LinkVisited = true;
            System.Diagnostics.Process.Start("https://toolboxservico.space");
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.linkLabel3.LinkVisited = true;
            System.Diagnostics.Process.Start("http://toolboxservico.space/admin");
        }
    }
}
