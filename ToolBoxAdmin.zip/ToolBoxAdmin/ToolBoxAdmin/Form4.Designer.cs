﻿namespace ToolBoxAdmin
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.panelSideMenu = new System.Windows.Forms.Panel();
            this.panelButtons = new System.Windows.Forms.Panel();
            this.bpedidos = new System.Windows.Forms.Button();
            this.panelBgeral = new System.Windows.Forms.Panel();
            this.bOrcamento = new System.Windows.Forms.Button();
            this.bServicos = new System.Windows.Forms.Button();
            this.bCadastrarServico = new System.Windows.Forms.Button();
            this.bHome = new System.Windows.Forms.Button();
            this.bSair = new System.Windows.Forms.Button();
            this.panelBemVindo = new System.Windows.Forms.Panel();
            this.labelWelcome = new System.Windows.Forms.Label();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.richTextBoxNomeServ = new System.Windows.Forms.RichTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxServico = new System.Windows.Forms.ComboBox();
            this.button3 = new System.Windows.Forms.Button();
            this.panelSideMenu.SuspendLayout();
            this.panelButtons.SuspendLayout();
            this.panelBgeral.SuspendLayout();
            this.panelBemVindo.SuspendLayout();
            this.panelLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // panelSideMenu
            // 
            this.panelSideMenu.BackColor = System.Drawing.Color.White;
            this.panelSideMenu.Controls.Add(this.panelButtons);
            this.panelSideMenu.Controls.Add(this.bSair);
            this.panelSideMenu.Controls.Add(this.panelBemVindo);
            this.panelSideMenu.Controls.Add(this.panelLogo);
            this.panelSideMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSideMenu.Location = new System.Drawing.Point(0, 0);
            this.panelSideMenu.Name = "panelSideMenu";
            this.panelSideMenu.Size = new System.Drawing.Size(280, 681);
            this.panelSideMenu.TabIndex = 7;
            // 
            // panelButtons
            // 
            this.panelButtons.BackColor = System.Drawing.Color.White;
            this.panelButtons.Controls.Add(this.bpedidos);
            this.panelButtons.Controls.Add(this.panelBgeral);
            this.panelButtons.Controls.Add(this.bHome);
            this.panelButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelButtons.Location = new System.Drawing.Point(0, 151);
            this.panelButtons.Name = "panelButtons";
            this.panelButtons.Size = new System.Drawing.Size(280, 501);
            this.panelButtons.TabIndex = 13;
            // 
            // bpedidos
            // 
            this.bpedidos.Dock = System.Windows.Forms.DockStyle.Top;
            this.bpedidos.FlatAppearance.BorderSize = 0;
            this.bpedidos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bpedidos.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bpedidos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bpedidos.Image = ((System.Drawing.Image)(resources.GetObject("bpedidos.Image")));
            this.bpedidos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bpedidos.Location = new System.Drawing.Point(0, 160);
            this.bpedidos.Name = "bpedidos";
            this.bpedidos.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bpedidos.Size = new System.Drawing.Size(280, 40);
            this.bpedidos.TabIndex = 8;
            this.bpedidos.Text = "  sugestões";
            this.bpedidos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bpedidos.UseVisualStyleBackColor = true;
            this.bpedidos.Click += new System.EventHandler(this.bpedidos_Click);
            // 
            // panelBgeral
            // 
            this.panelBgeral.Controls.Add(this.bOrcamento);
            this.panelBgeral.Controls.Add(this.bServicos);
            this.panelBgeral.Controls.Add(this.bCadastrarServico);
            this.panelBgeral.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelBgeral.Location = new System.Drawing.Point(0, 40);
            this.panelBgeral.Name = "panelBgeral";
            this.panelBgeral.Size = new System.Drawing.Size(280, 120);
            this.panelBgeral.TabIndex = 7;
            // 
            // bOrcamento
            // 
            this.bOrcamento.Dock = System.Windows.Forms.DockStyle.Top;
            this.bOrcamento.FlatAppearance.BorderSize = 0;
            this.bOrcamento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bOrcamento.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bOrcamento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bOrcamento.Image = ((System.Drawing.Image)(resources.GetObject("bOrcamento.Image")));
            this.bOrcamento.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bOrcamento.Location = new System.Drawing.Point(0, 80);
            this.bOrcamento.Name = "bOrcamento";
            this.bOrcamento.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.bOrcamento.Size = new System.Drawing.Size(280, 40);
            this.bOrcamento.TabIndex = 4;
            this.bOrcamento.Text = "  cadastrar novo serviço";
            this.bOrcamento.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bOrcamento.UseVisualStyleBackColor = true;
            this.bOrcamento.Click += new System.EventHandler(this.bOrcamento_Click);
            // 
            // bServicos
            // 
            this.bServicos.Dock = System.Windows.Forms.DockStyle.Top;
            this.bServicos.FlatAppearance.BorderSize = 0;
            this.bServicos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bServicos.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bServicos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bServicos.Image = ((System.Drawing.Image)(resources.GetObject("bServicos.Image")));
            this.bServicos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bServicos.Location = new System.Drawing.Point(0, 40);
            this.bServicos.Name = "bServicos";
            this.bServicos.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.bServicos.Size = new System.Drawing.Size(280, 40);
            this.bServicos.TabIndex = 7;
            this.bServicos.Text = "  serviços";
            this.bServicos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bServicos.UseVisualStyleBackColor = true;
            this.bServicos.Click += new System.EventHandler(this.bServicos_Click);
            // 
            // bCadastrarServico
            // 
            this.bCadastrarServico.Dock = System.Windows.Forms.DockStyle.Top;
            this.bCadastrarServico.FlatAppearance.BorderSize = 0;
            this.bCadastrarServico.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bCadastrarServico.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bCadastrarServico.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bCadastrarServico.Image = ((System.Drawing.Image)(resources.GetObject("bCadastrarServico.Image")));
            this.bCadastrarServico.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bCadastrarServico.Location = new System.Drawing.Point(0, 0);
            this.bCadastrarServico.Name = "bCadastrarServico";
            this.bCadastrarServico.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.bCadastrarServico.Size = new System.Drawing.Size(280, 40);
            this.bCadastrarServico.TabIndex = 2;
            this.bCadastrarServico.Text = "  home";
            this.bCadastrarServico.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bCadastrarServico.UseVisualStyleBackColor = true;
            this.bCadastrarServico.Click += new System.EventHandler(this.bCadastrarServico_Click);
            // 
            // bHome
            // 
            this.bHome.BackColor = System.Drawing.Color.Transparent;
            this.bHome.Dock = System.Windows.Forms.DockStyle.Top;
            this.bHome.FlatAppearance.BorderSize = 0;
            this.bHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bHome.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bHome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bHome.Image = ((System.Drawing.Image)(resources.GetObject("bHome.Image")));
            this.bHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bHome.Location = new System.Drawing.Point(0, 0);
            this.bHome.Name = "bHome";
            this.bHome.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bHome.Size = new System.Drawing.Size(280, 40);
            this.bHome.TabIndex = 6;
            this.bHome.Text = "  geral";
            this.bHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bHome.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bHome.UseVisualStyleBackColor = false;
            this.bHome.Click += new System.EventHandler(this.bHome_Click);
            // 
            // bSair
            // 
            this.bSair.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bSair.FlatAppearance.BorderSize = 0;
            this.bSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bSair.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bSair.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bSair.Location = new System.Drawing.Point(0, 652);
            this.bSair.Name = "bSair";
            this.bSair.Size = new System.Drawing.Size(280, 29);
            this.bSair.TabIndex = 6;
            this.bSair.Text = "sair";
            this.bSair.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.bSair.UseVisualStyleBackColor = true;
            this.bSair.Click += new System.EventHandler(this.bSair_Click);
            // 
            // panelBemVindo
            // 
            this.panelBemVindo.Controls.Add(this.labelWelcome);
            this.panelBemVindo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelBemVindo.Location = new System.Drawing.Point(0, 86);
            this.panelBemVindo.Name = "panelBemVindo";
            this.panelBemVindo.Size = new System.Drawing.Size(280, 65);
            this.panelBemVindo.TabIndex = 1;
            // 
            // labelWelcome
            // 
            this.labelWelcome.AutoSize = true;
            this.labelWelcome.BackColor = System.Drawing.Color.Transparent;
            this.labelWelcome.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.labelWelcome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.labelWelcome.Location = new System.Drawing.Point(12, 22);
            this.labelWelcome.Name = "labelWelcome";
            this.labelWelcome.Size = new System.Drawing.Size(67, 25);
            this.labelWelcome.TabIndex = 1;
            this.labelWelcome.Text = "Admin";
            this.labelWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelLogo
            // 
            this.panelLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panelLogo.Controls.Add(this.pictureBoxLogo);
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.panelLogo.Size = new System.Drawing.Size(280, 86);
            this.panelLogo.TabIndex = 0;
            // 
            // pictureBoxLogo
            // 
            this.pictureBoxLogo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxLogo.ErrorImage = null;
            this.pictureBoxLogo.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogo.Image")));
            this.pictureBoxLogo.InitialImage = null;
            this.pictureBoxLogo.Location = new System.Drawing.Point(0, 5);
            this.pictureBoxLogo.Name = "pictureBoxLogo";
            this.pictureBoxLogo.Size = new System.Drawing.Size(280, 86);
            this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxLogo.TabIndex = 0;
            this.pictureBoxLogo.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label11.Location = new System.Drawing.Point(379, 111);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(240, 37);
            this.label11.TabIndex = 71;
            this.label11.Text = "Cadastrar serviço";
            // 
            // richTextBoxNomeServ
            // 
            this.richTextBoxNomeServ.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBoxNomeServ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBoxNomeServ.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.richTextBoxNomeServ.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.richTextBoxNomeServ.Location = new System.Drawing.Point(386, 276);
            this.richTextBoxNomeServ.MaxLength = 256;
            this.richTextBoxNomeServ.Name = "richTextBoxNomeServ";
            this.richTextBoxNomeServ.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.richTextBoxNomeServ.Size = new System.Drawing.Size(730, 164);
            this.richTextBoxNomeServ.TabIndex = 78;
            this.richTextBoxNomeServ.Text = "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label4.Location = new System.Drawing.Point(381, 248);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(151, 25);
            this.label4.TabIndex = 77;
            this.label4.Text = "nome do serviço";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label1.Location = new System.Drawing.Point(381, 170);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 25);
            this.label1.TabIndex = 76;
            this.label1.Text = "serviço";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // comboBoxServico
            // 
            this.comboBoxServico.AutoCompleteCustomSource.AddRange(new string[] {
            "Aquacultura",
            "Concepção de projeto paisagístico",
            "Confecção de coroas de flores",
            "Cultivo de plantas",
            "Destruição de ervas daninhas",
            "Horticultura",
            "Jardinagem",
            "Jardinagem paisagística",
            "Manutenção de gramados",
            "Plantação de árvores com a finalidade de compensação de carbono",
            "Reflorestamento",
            "Serviços de arranjo de flores",
            "Desenho de plantas para construção",
            "Desenho industrial",
            "Pesquisa e desenvolvimento, para terceiros, de novos produtos",
            "Planejamento urbano",
            "Aulas de ginástica",
            "Aulas particulares",
            "Avaliação de aptidão física para fins de treinamento",
            "Cronometragem de eventos desportivos",
            "Análise para exploração de campos petrolíferos",
            "Análises químicas",
            "Arquitetura",
            "Cartografia",
            "Consultoria em arquitetura",
            "Consultoria em tecnologia das telecomunicações",
            "Consultoria na área de economia de energia",
            "Criação em artes gráficas",
            "Desenho de embalagens",
            "Design de interiores",
            "Escrita técnica",
            "Estilismo",
            "Explorações subaquáticas",
            "Levantamentos em campos petrolíferos",
            "Levantamentos geodésicos",
            "Levantamentos geológicos",
            "Levantamentos topográficos",
            "Pesquisa bacteriológica",
            "Pesquisa biológica",
            "Pesquisa científica",
            "Pesquisas científicas e tecnológicas no campo de desastres naturais",
            "Pesquisas em mecânica",
            "Pesquisas geológicas",
            "Pesquisas no campo da física",
            "Pesquisas no campo de proteção ambiental",
            "Pesquisas químicas",
            "Pesquisas tecnológicas",
            "Realização de estudos para projetos técnicos",
            "Recuperação de dados",
            "Alvenaria",
            "Asfaltamento",
            "Assentamento de tijolos",
            "Carpintaria",
            "Cobertura de telhado",
            "Colocação de papel de parede",
            "Conservação, limpeza e conserto de peles",
            "Construção de fábricas",
            "Construção de portos",
            "Construção de quebra-mar",
            "Construção e manutenção de oleoduto",
            "Construção e reparos de armazém",
            "Construção naval",
            "Construção subaquática",
            "Consultoria na área de construção civil",
            "Demolição de edificações",
            "Doméstica",
            "Elétrica",
            "Encanamento",
            "Impermeabilização de edificações",
            "Montagem de andaimes",
            "Pavimentação de rua",
            "Pintura ou reparo de letreiros",
            "Pintura, de interior e de exterior",
            "Reboco",
            "Serviços de isolamento para edificações",
            "Supervisão de trabalhos de construção civil",
            "Monitoramento de sistemas de computador para detecção de acesso não autorizado ou" +
                " vazamento de dados",
            "Monitoramento de sistemas de computador para detecção de panes",
            "Teste de materiais",
            "Teste de têxteis",
            "Testes em poços de petróleo",
            "Vistoria de veículos automotores",
            "Adestramento de animais",
            "Aulas particulares",
            "Educação física",
            "Educação religiosa",
            "Elaboração de roteiros",
            "Exames pedagógicos",
            "Fotografia",
            "Instrução de aulas de atividade física",
            "Interpretação de idiomas",
            "Interpretação de linguagem de sinais (Libras)",
            "Legendagem",
            "Organização de exposições para fins culturais ou educativos",
            "Organização e apresentação de conferências",
            "Organização e apresentação de congressos",
            "Organização e apresentação de oficinas de trabalho",
            "Organização e apresentação de seminários",
            "Provimento de informações sobre educação",
            "Provimento de vídeos on-line",
            "Publicação de livros",
            "Publicação de textos",
            "Publicação on-line de livros e periódicos eletrônicos",
            "Reciclagem profissional",
            "Roteirização",
            "Serviços de caligrafia",
            "Serviços de composição musical",
            "Tradução",
            "Treinamento através de simuladores",
            "Armazenagem de mercadorias",
            "Armazenamento de bagagens",
            "Depósito",
            "Embalagem de mercadorias",
            "Embalagem de pacotes",
            "Embalagem de presentes",
            "Agenciamento de ingressos",
            "Apresentação de espetáculos ao vivo",
            "Apresentação de espetáculos circenses",
            "Apresentação de espetáculos de variedades",
            "Coaching",
            "Composição de canções",
            "Condução de visitas guiadas",
            "DJ",
            "Direção de filmes",
            "Dublagem",
            "Editoração eletrônica",
            "Edição de videoteipe",
            "Edição de vídeos",
            "Filmagem em vídeo",
            "Organização de competições",
            "Organização de competições desportivas",
            "Organização de concursos de beleza",
            "Organização de desfiles de moda para fins de entretenimento",
            "Organização de espetáculos",
            "Organização e regência de concertos",
            "Orientação vocacional",
            "Orquestra",
            "Planejamento de festas",
            "Produção de filmes",
            "Produção de programas de rádio e televisão",
            "Produção de shows",
            "Produção musical",
            "Produções teatrais",
            "Programas de entretenimento de rádio",
            "Programas de entretenimento de televisão",
            "Projeções de filmes cinematográficos",
            "Serviços de boates",
            "Extração de pedras",
            "Extração mineral",
            "Lixamento",
            "Lubrificação de veículos",
            "Mineração",
            "Perfuração de poços",
            "Perfuração de poços profundos de petróleo ou de gás.",
            "Administração financeira",
            "Análise financeira",
            "Avaliação de antiguidades",
            "Avaliação de arte",
            "Avaliação de joias",
            "Avaliação financeira",
            "Avaliação financeira de ativos de propriedade intelectual",
            "Avaliação financeira de lã",
            "Avaliação financeira de madeira em pé",
            "Avaliações financeiras para responder a licitações",
            "Captação de fundos para caridade",
            "Cobrança financeira",
            "Cobranças de dívidas",
            "Consultoria financeira",
            "Corretagem de ações",
            "Corretagem de ações e títulos",
            "Corretagem de valores",
            "Cotações de bolsa de valores",
            "Depósito em cofres bancários",
            "Depósitos de objetos de valor",
            "Elaboração de cotações para fins de estimativa de custos",
            "Emissão de cartões de crédito",
            "Emissão de cheques de viagem",
            "Emissão de títulos de valor",
            "Empréstimo com garantia de ações",
            "Financiamento",
            "Finança de agências alfandegárias",
            "Fundos de previdência",
            "Fundos mútuos",
            "Gestão financeira de pagamento de reembolsos para terceiros",
            "Intermediação de créditos de carbono",
            "Investimentos de capital",
            "Liquidação financeira",
            "Notificação de débitos",
            "Operações de câmbio",
            "Operações de câmbio de moeda virtual",
            "Orçamento",
            "Pagamento de fianças",
            "Patrocínio financeiro",
            "Pesquisas financeiras",
            "Provimento de informações financeiras",
            "Provimento de informações financeiras através de uma website",
            "Serviços bancários de poupança",
            "Serviços de penhor",
            "Transferência eletrônica de fundos",
            "Transferência eletrônica de moedas virtuais",
            "Verificação de validade de cheque",
            "Assessoria de imprensa",
            "Atualização e manutenção de informações em registros",
            "Digitação",
            "Caixa postal de voz",
            "Comunicação corporativa",
            "Lembrete de compromissos",
            "Marcação de compromissos",
            "Processamento de texto",
            "Registro de dados e comunicação escritos",
            "Registro de listas de presentes",
            "Relações públicas",
            "Secretariado",
            "Secretária eletrônica",
            "Serviços de central telefônica",
            "Telemarketing",
            "Administração comercial do licenciamento de produtos e serviços de terceiros",
            "Administração de negócios de esportistas",
            "Administração de negócios de programas de reembolso para terceiros",
            "Administração de programas de fidelidade de consumidores",
            "Administração de programas de milhas de viagens",
            "Administração de programas de viajantes frequentes",
            "Administração para encaminhamentos médicos",
            "Administração para realocação de empresas",
            "Análise de custo",
            "Apresentação de produtos em meios de comunicação para fins de comércio varejista",
            "Assessoria em gestão comercial ou industrial",
            "Assessoria em gestão de negócios",
            "Assessoria em gestão industrial ou comercial",
            "Assistência administrativa",
            "Assistência administrativa para responder a licitações",
            "Atualização e manutenção de dados em bancos de dados de computadores",
            "Auditoria contábil e financeira",
            "Auditoria em negócios",
            "Auxílio em gestão de negócios",
            "Avaliações de negócios",
            "Busca de dados em arquivos de computador para terceiros",
            "Comparação de Preços",
            "Compilação de informação em bancos de dados de computador",
            "Compilações de estatísticas",
            "Consultoria em gestão de negócios",
            "Consultoria em gestão de pessoal",
            "Consultoria em gestão e organização de negócios",
            "Consultoria em organização de negócios",
            "Consultoria profissional em negócios",
            "Contabilidade",
            "Declaração de impostos",
            "Elaboração de currículos para terceiros",
            "Elaboração de extratos de contas",
            "Especialistas em eficiência de negócios",
            "Faturamento",
            "Gestão administrativa de hotéis",
            "Gestão administrativa terceirizada para empresas",
            "Gestão computadorizada de arquivos Indexação na web para fins comerciais ou publi" +
                "citários",
            "Gestão de negócios para projetos de construção",
            "Gestão de negócios para provedores de serviços freelance",
            "Gestão interina de negócios",
            "Inteligência de mercado",
            "Intermediação comercial",
            "Investigações de Negócios",
            "Leilões",
            "Levantamentos de informações de negócios",
            "Negociação de contratos de negócios para terceiros",
            "Negociação e conclusão de transações comerciais para terceiros",
            "Organização de feiras comerciais",
            "Otimização de tráfego de website",
            "Pesquisa em negócios",
            "Preparação de declarações de impostos",
            "Preparação de folha de pagamento",
            "Preparações sanitárias, farmacêuticas e veterinárias de suprimentos médicos",
            "Previsões econômicas",
            "Processamento administrativo de pedidos de compra",
            "Recrutamento de pessoal",
            "Serviços de inteligência competitiva",
            "Sistematização de informações em bancos de dados de computador",
            "Venda de assinaturas de serviços de telecomunicações para terceiros",
            "Vendas de assinaturas de jornal",
            "Análise de sistemas",
            "Armazenamento eletrônico de dados",
            "Atualização de software de computador",
            "Backup de dados off site",
            "Computação em nuvem",
            "Consultoria em concepção e desenvolvimento de hardware de computador",
            "Consultoria em design de websites",
            "Consultoria em segurança de computadores",
            "Consultoria em segurança de dados",
            "Consultoria em segurança de internet",
            "Consultoria em software de computador",
            "Consultoria em tecnologia da computação",
            "Consultoria em tecnologia da informação",
            "Conversão de dados e documentos de suporte físico para suporte eletrônico",
            "Conversão de programas de computadores e dados, exceto conversão física",
            "Criação e concepção de índices de informação baseados em um website, para terceir" +
                "os",
            "Criação e manutenção de websites para terceiros",
            "Desenvolvimento de software no âmbito de publicação de software",
            "Duplicação de programas de computador",
            "Elaboração de software de computador",
            "Instalação de software de computador",
            "Manutenção de software de computador",
            "Plataforma computacional como serviço",
            "Programação de computador",
            "Projeto de sistema de computadores",
            "Proteção contra vírus de computador",
            "Software como serviço",
            "Cabeleireiro",
            "Manicure",
            "Tatuagem",
            "Encadernação",
            "Impressão",
            "Impressão 3D para terceiros",
            "Impressão de estampas",
            "Impressão fotográfica",
            "Impressão litográfica",
            "Afiação de faca",
            "Afinação de instrumentos musicais",
            "Balanceamento de pneus",
            "Carregamento de baterias de veículos",
            "Chaveiro",
            "Conserto de bomba",
            "Conserto de estofamento",
            "Conserto de sapatos",
            "Desinfecção",
            "Envernizamento",
            "Esterilização de instrumentos médicos",
            "Estofamento de móveis",
            "Fraturamento hidráulico",
            "Instalação de cabos",
            "Instalação de equipamentos de cozinha",
            "Instalação de portas e janelas",
            "Instalação de serviços básicos de infraestrutura em locais de construção",
            "Instalação e reparo de alarme antifurto",
            "Instalação e reparo de alarmes de incêndio",
            "Instalação e reparo de aparelhos de ar condicionado",
            "Instalação e reparo de aparelhos elétricos",
            "Instalação e reparo de dispositivos de irrigação",
            "Instalação e reparo de elevadores",
            "Instalação e reparo de equipamentos de aquecimento",
            "Instalação e reparo de equipamentos de proteção contra inundações",
            "Instalação e reparo de equipamentos de refrigeração",
            "Instalação e reparo de fornos",
            "Instalação e reparo telefones",
            "Instalação, manutenção e reparo de computadores",
            "Instalação, manutenção e reparo de máquinas",
            "Instalação, manutenção e reparo de máquinas e equipamentos de escritório",
            "Lavagem",
            "Lavagem a seco",
            "Lavagem de fraldas",
            "Lavagem de roupa",
            "Lavagem de veículos",
            "Lavanderia",
            "Limpeza de chaminé",
            "Limpeza de fachada de edificações",
            "Limpeza de interiores de edifícios",
            "Limpeza de janelas",
            "Limpeza de roupas",
            "Limpeza de rua",
            "Limpeza de veículo",
            "Limpeza e reparo de caldeira",
            "Manutenção de aparelhos fotográficos",
            "Manutenção de mobiliário",
            "Manutenção de piscinas",
            "Manutenção de veículos",
            "Manutenção e reparo de aeronaves",
            "Manutenção e reparo de automóveis",
            "Manutenção e reparo de caixas-fortes",
            "Manutenção e reparo de cofre",
            "Manutenção e reparo de queimadores",
            "Montagem de estandes de feira de exposições e lojas",
            "Passar roupa a ferro",
            "Polimento de veículo",
            "Prensagem para passar roupa",
            "Rebitagem",
            "Recarga de bateria para telefones celulares",
            "Recarga de cartuchos a jato de tinta",
            "Recarga de cartuchos de toner",
            "Recarga de veículos elétricos",
            "Recauchutagem de pneus",
            "Recondicionamento de motores desgastados ou parcialmente destruídos",
            "Recondicionamento de máquinas desgastadas ou parcialmente destruídas",
            "Recondicionamento de roupas",
            "Remoção de neve",
            "Reparo de fechaduras de segurança",
            "Reparo de guarda-chuvas e guarda-sol",
            "Reparo de linhas de transmissão de energia",
            "Reparo de panes em veículos",
            "Reparo de roupas",
            "Reparo e manutenção de projetor de filmes",
            "Reparos de relógios",
            "Reparos subaquáticos",
            "Restauração de instrumentos musicais",
            "Restauração de mobiliário",
            "Restauração de obras de arte",
            "Supressão de interferência em aparelhos elétricos",
            "Tratamento antiferrugem",
            "Tratamento antioxidante para veículos",
            "Tratamento, limpeza e conserto de couro",
            "Vulcanização de pneus",
            "Aconselhamento jurídico para responder a licitações",
            "Advogado",
            "Auditoria para fins de conformidade jurídica",
            "Auditoria para fins de conformidade regulatória",
            "Consultoria em propriedade intelectual s",
            "Gestão de direitos autorais",
            "Licenciamento de programa de computador",
            "Licenciamento de propriedade intelectual",
            "Monitoramento jurídico",
            "Pesquisas jurídicas",
            "Preparação de documentos jurídicos",
            "Serviços jurídicos relativos à negociação de contratos para terceiros",
            "Decoração de alimentos",
            "Decoração de bolos",
            "Escultura em alimentos",
            "Administração de imóveis",
            "Administração predial",
            "Avaliação imobiliária Câmara de Compensação",
            "Captação de financiamento para projetos de construção",
            "Corretagem imobiliária",
            "Locação de apartamentos",
            "Locação de fazendas ação de imóveis",
            "Negócios imobiliários",
            "Operações bancárias de hipoteca",
            "Organização de cruzeiros",
            "Organização de transporte para excursões",
            "Reserva de assentos para viagem",
            "Reservas para transporte",
            "Reservas para viagens",
            "Arbitragem",
            "Babá",
            "Babá de animais",
            "Detetives",
            "Investigações de antecedentes de pessoas",
            "Investigações de pessoas desaparecidas",
            "Rastreamento de bens roubados",
            "Afixação de mensagens publicitárias",
            "Agenciamento de artistas",
            "Agências de modelos para publicidade ou promoção de vendas",
            "Atualização de material publicitário",
            "Captação de patrocínio",
            "Comerciais de rádio",
            "Comerciais de televisão",
            "Compilação de índices de informações para fins comerciais ou publicitários",
            "Comércio de produtos de panificação",
            "Decoração de vitrines",
            "Demonstração de produtos",
            "Desenvolvimento de conceitos de campanha publicitária",
            "Distribuição de amostras",
            "Distribuição de material publicitário",
            "Estudos de marketing",
            "Informação comercial",
            "Layout para fins publicitários",
            "Marketing",
            "Marketing direcionado",
            "Marketing no âmbito de publicação de softwares",
            "Organização de eventos de moda para fins promocionais",
            "Organização de exposições para fins comerciais ou publicitários",
            "Otimização de ferramenta de busca para fins de promoção de vendas",
            "Pesquisa de marketing",
            "Pesquisas de opinião",
            "Produção de filmes publicitários",
            "Promoção de vendas para terceiros",
            "Propaganda",
            "Publicação de textos publicitários",
            "Publicidade",
            "Publicidade de rádio",
            "Publicidade de televisão",
            "Publicidade externa",
            "Publicidade on-line em rede de computadores",
            "Publicidade por catálogos de vendas",
            "Redação de roteiros para fins publicitários",
            "Redação de textos publicitários",
            "Desodorização de ar",
            "Purificação de ar",
            "Descontaminação de materiais perigosos",
            "Destruição de lixo e resíduos",
            "Reciclagem de lixo e resíduos",
            "Abertura de fechaduras de segurança",
            "Combate ao fogo",
            "Consultoria em segurança física",
            "Guarda",
            "Guarda noturna",
            "Guarda-costas pessoal",
            "Inspeção de fábricas para fins de segurança",
            "Monitorização de alarmes anti-roubo e de segurança",
            "Salva-vidas",
            "Segurança pessoal",
            "Verificação de segurança de bagagens",
            "Vigilância noturna",
            "Consultoria em seguros Avaliação fiscal",
            "Corretagem de seguros",
            "Provimento de informações sobre seguros",
            "Seguro contra acidentes",
            "Seguros",
            "Seguros contra incêndio",
            "Seguros de saúde",
            "Seguros de vida",
            "Seguros marítimos",
            "Comunicação por redes de fibra óptica",
            "Comunicação por rádio",
            "Comunicação por telefone celular",
            "Comunicação por terminais de computador",
            "Comunicações por telefone",
            "Radiodifusão",
            "Telefonia",
            "Afretamento",
            "Carga e descarga para barcaças",
            "Carregamento de bagagens",
            "Coleta de bens recicláveis",
            "Corretagem de transporte",
            "Corretagem marítima",
            "Descarregamento",
            "Entrega de flores",
            "Entrega de jornais",
            "Entrega de mensagens",
            "Entrega de mercadorias",
            "Entrega de mercadorias por catálogo",
            "Entrega de pacotes",
            "Expedição de frete",
            "Frete",
            "Operações de resgate",
            "Pilotagem",
            "Reboque",
            "Reboque de veículos em pane",
            "Salvamento de navios",
            "Salvamento subaquático",
            "Serviços de transporte para visitas turísticas",
            "Transporte aéreo",
            "Transporte de móveis",
            "Transporte de passageiros",
            "Transporte de viajantes",
            "Transporte e armazenagem de detritos",
            "Transporte e armazenagem de lixo",
            "Transporte em embarcação para recreio",
            "Transporte ferroviário",
            "Transporte por ambulância",
            "Transporte por barco",
            "Transporte por bondes",
            "Transporte por caminhão",
            "Transporte por carro",
            "Transporte por carro-forte",
            "Transporte por carroças",
            "Transporte por táxi",
            "Transporte por ônibus",
            "Transporte, sob escolta, de valores",
            "Alfaiataria",
            "Aplainamento de materiais",
            "Aplicação de película em vidros de carros",
            "Banho de ouro",
            "Branqueamento de tecidos",
            "Brasagem",
            "Coloração de vidros de janelas por meio de revestimento da superfície",
            "Confecção de roupas",
            "Corte de tecidos",
            "Cromagem",
            "Derrubada e processamento de madeira",
            "Douração",
            "Esmerilhamento",
            "Estanhagem",
            "Ferreiro",
            "Impermeabilização de tecidos",
            "Jateamento abrasivo",
            "Laminação",
            "Magnetização",
            "Metalizar",
            "Modelagem de peles sob medida",
            "Modificação de roupas",
            "Molduragem de obras de arte",
            "Montagem de materiais sob encomenda de terceiros",
            "Pintura para calçados",
            "Pisoamento de tecidos",
            "Polimento de vidro óptico",
            "Refino",
            "Serragem de materiais",
            "Soldagem",
            "Tinturaria",
            "Trabalhos em madeira",
            "Tratamento de lã",
            "Tratamento de metal",
            "Tratamento de tecidos",
            "Tratamento de têxteis",
            "Tratamento de água",
            "Tratamento para papel",
            "Assistência veterinária",
            "Criação de animais"});
            this.comboBoxServico.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.comboBoxServico.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBoxServico.BackColor = System.Drawing.SystemColors.Control;
            this.comboBoxServico.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxServico.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.comboBoxServico.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.comboBoxServico.FormattingEnabled = true;
            this.comboBoxServico.Location = new System.Drawing.Point(386, 198);
            this.comboBoxServico.Name = "comboBoxServico";
            this.comboBoxServico.Size = new System.Drawing.Size(730, 33);
            this.comboBoxServico.TabIndex = 75;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(131)))), ((int)(((byte)(238)))));
            this.button3.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(836, 459);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(280, 48);
            this.button3.TabIndex = 79;
            this.button3.Text = "Cadastrar serviço";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.richTextBoxNomeServ);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBoxServico);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.panelSideMenu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form4";
            this.Text = "Cadastrar serviço";
            this.Load += new System.EventHandler(this.Form4_Load);
            this.panelSideMenu.ResumeLayout(false);
            this.panelButtons.ResumeLayout(false);
            this.panelBgeral.ResumeLayout(false);
            this.panelBemVindo.ResumeLayout(false);
            this.panelBemVindo.PerformLayout();
            this.panelLogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelSideMenu;
        private System.Windows.Forms.Panel panelButtons;
        private System.Windows.Forms.Button bSair;
        private System.Windows.Forms.Panel panelBemVindo;
        private System.Windows.Forms.Label labelWelcome;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.PictureBox pictureBoxLogo;
        private System.Windows.Forms.Button bpedidos;
        private System.Windows.Forms.Panel panelBgeral;
        private System.Windows.Forms.Button bOrcamento;
        private System.Windows.Forms.Button bServicos;
        private System.Windows.Forms.Button bCadastrarServico;
        private System.Windows.Forms.Button bHome;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.RichTextBox richTextBoxNomeServ;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxServico;
        private System.Windows.Forms.Button button3;
    }
}