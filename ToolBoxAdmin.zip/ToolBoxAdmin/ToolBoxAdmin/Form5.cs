﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ToolBoxAdmin
{
    public partial class Form5 : Form
    {
        MySqlConnection con;
        Thread nt;
        int idcategoria;
        public Form5()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            try
            {
                con = new MySqlConnection("server=143.106.241.3;port=3306;UserID=cl19248;database=cl19248;password=cl19248");
            }
            catch
            {
                MessageBox.Show("Falha na conexão");
            }
        }

        #region buttons home
        private void bHome_Click(object sender, EventArgs e)
        {
            if (panelBgeral.Visible == false)
            {
                this.bHome.BackColor = System.Drawing.Color.AliceBlue;
                panelBgeral.Visible = true;
            }
            else
            {
                this.bHome.BackColor = System.Drawing.Color.White;
                panelBgeral.Visible = false;
            }
        }

        private void bpedidos_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Sugestao);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bCadastrarServico_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Home);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bServicos_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Servicos);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bOrcamento_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(CadastrarServico);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bSair_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Sair);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void Sair()
        {
            Application.Run(new Form1());
        }

        private void CadastrarServico()
        {
            Application.Run(new Form4());
        }

        private void Servicos()
        {
            Application.Run(new Form3());
        }

        private void Home()
        {
            Application.Run(new Form2());
        }

        private void Sugestao()
        {
            Application.Run(new Form5());
        }
        #endregion

        private void Form5_Load(object sender, EventArgs e)
        {
            panelBgeral.Visible = false;
            dataGridViewSugestao.Location = new Point((this.Size.Width / 2 - dataGridViewSugestao.Size.Width / 2) - 300, 40);
            dataGridViewSugestao.Anchor = AnchorStyles.None;
            bNRepondidos_Click( sender,  e);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bAceitos.BackColor = Color.FromArgb(240, 240, 240);
            bRecusados.BackColor = Color.FromArgb(240, 240, 240);
            bNRepondidos.BackColor = Color.FromArgb(240, 240, 240);
            //DisplayService();
        }

        private void bPesquisar_Click(object sender, EventArgs e)
        {
            bRecusados.BackColor = Color.FromArgb(240, 240, 240);
            bAceitos.BackColor = Color.FromArgb(240, 240, 240);
            bNRepondidos.BackColor = Color.FromArgb(240, 240, 240);

            dataGridViewSugestao.AutoGenerateColumns = false;

            dataGridViewSugestao.Columns["Column1"].DisplayIndex = 0;
            dataGridViewSugestao.Columns["Column2"].DisplayIndex = 1;
            dataGridViewSugestao.Columns["Column3"].DisplayIndex = 2;
            dataGridViewSugestao.Columns["Column5"].DisplayIndex = 3;
            dataGridViewSugestao.Columns["Column6"].DisplayIndex = 4;
            dataGridViewSugestao.Columns["Column5"].Visible = false;
            dataGridViewSugestao.Columns["Column6"].Visible = false;

            try
            {
                con.Open();
                MySqlCommand display_servico = new MySqlCommand("select idsuggestion, idcategory, dessuggestion,dtrequest,descategory from tb_servicesuggestions inner join tb_categories using(idcategory) where tb_servicesuggestions.idcategory = tb_categories.idcategory and tb_servicesuggestions.dessuggestion LIKE '%" + textBoxPesquisar.Text + "%' or tb_categories.descategory LIKE '%" + textBoxPesquisar.Text + "%' or tb_servicesuggestions.dtrequest LIKE '%" + textBoxPesquisar.Text + "%';", con);

                MySqlDataAdapter da = new MySqlDataAdapter(display_servico);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewSugestao.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            con.Close();
        }

        private void textBoxPesquisar_TextChanged(object sender, EventArgs e)
        {
            bRecusados.BackColor = Color.FromArgb(240, 240, 240);
            bAceitos.BackColor = Color.FromArgb(240, 240, 240);
            bNRepondidos.BackColor = Color.FromArgb(240, 240, 240);

            dataGridViewSugestao.AutoGenerateColumns = false;

            dataGridViewSugestao.Columns["Column1"].DisplayIndex = 0;
            dataGridViewSugestao.Columns["Column2"].DisplayIndex = 1;
            dataGridViewSugestao.Columns["Column3"].DisplayIndex = 2;
            dataGridViewSugestao.Columns["Column5"].DisplayIndex = 3;
            dataGridViewSugestao.Columns["Column6"].DisplayIndex = 4;
            dataGridViewSugestao.Columns["Column5"].Visible = false;
            dataGridViewSugestao.Columns["Column6"].Visible = false;

            try
            {
                con.Open();
                MySqlCommand display_servico = new MySqlCommand("select idsuggestion, idcategory, dessuggestion,dtrequest,descategory from tb_servicesuggestions inner join tb_categories using(idcategory) where tb_servicesuggestions.idcategory = tb_categories.idcategory and tb_servicesuggestions.dessuggestion LIKE '%" + textBoxPesquisar.Text + "%' or tb_categories.descategory LIKE '%" + textBoxPesquisar.Text + "%' or tb_servicesuggestions.dtrequest LIKE '%" + textBoxPesquisar.Text + "%';", con);

                MySqlDataAdapter da = new MySqlDataAdapter(display_servico);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewSugestao.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            con.Close();
        }

        private void dataGridViewSugestao_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //MessageBox.Show(e.ColumnIndex + ""); 1064; 488        size 322; 231          location 1108; 51
            //MessageBox.Show(dataGridViewSugestao.Rows[e.RowIndex].Cells[0].Value.ToString() + " 0\n");
            if (e.ColumnIndex == 6)
            {
                DialogResult ask_forAcceptance = MessageBox.Show("Tem certeza que deseja aceitar essa sugestão?", "Sistema - ATENÇÃO", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult.Yes == ask_forAcceptance)
                {
                    panelAceitarServico.Location = new Point(dataGridViewSugestao.Location.X + dataGridViewSugestao.Size.Width + 20, 40);
                    panelAceitarServico.Anchor = AnchorStyles.None;
                    panelAceitarServico.Visible = true;

                    idcategoria = int.Parse(dataGridViewSugestao.Rows[e.RowIndex].Cells[1].Value.ToString());
                    int idsuggeston = int.Parse(dataGridViewSugestao.Rows[e.RowIndex].Cells[0].Value.ToString());

                    try
                    {
                        con.Open();
                        MySqlCommand Accepted = new MySqlCommand("update tb_servicesuggestions set situation = 1 where idsuggestion = '" + idsuggeston + "';", con);
                        Accepted.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Falha na conexão\nErro: " + ex.Message + "\n" + ex.ToString());
                    }
                    con.Close();
                    
                }
            }

            if (e.ColumnIndex == 7)
            {
                DialogResult ask_forRefusal = MessageBox.Show("Tem certeza que deseja recusar essa sugestão?", "Sistema - ATENÇÃO", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult.Yes == ask_forRefusal)
                {
                    int idsuggeston = int.Parse(dataGridViewSugestao.Rows[e.RowIndex].Cells[0].Value.ToString());

                    try
                    {
                        con.Open();
                        MySqlCommand Refused = new MySqlCommand("update tb_servicesuggestions set situation = 2 where idsuggestion = '" + idsuggeston + "';", con);
                        Refused.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Falha na conexão\nErro: " + ex.Message + "\n" + ex.ToString());
                    }
                    con.Close();

                    bRecusados_Click( sender,  e);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bAceitos.BackColor = Color.Silver;
            bRecusados.BackColor = Color.FromArgb(240, 240, 240);
            bNRepondidos.BackColor = Color.FromArgb(240, 240, 240);

            dataGridViewSugestao.AutoGenerateColumns = false;

            dataGridViewSugestao.Columns["Column1"].DisplayIndex = 0;
            dataGridViewSugestao.Columns["Column2"].DisplayIndex = 1;
            dataGridViewSugestao.Columns["Column3"].DisplayIndex = 2;
            dataGridViewSugestao.Columns["Column5"].DisplayIndex = 3;
            dataGridViewSugestao.Columns["Column6"].DisplayIndex = 4;
            dataGridViewSugestao.Columns["Column5"].Visible = false;
            dataGridViewSugestao.Columns["Column6"].Visible = false;

            try
            {
                con.Open();
                MySqlCommand display_sugestao = new MySqlCommand("select idsuggestion, idcategory, dessuggestion,dtrequest,descategory from tb_servicesuggestions inner join tb_categories using(idcategory) where tb_servicesuggestions.idcategory = tb_categories.idcategory and tb_servicesuggestions.situation = 1;", con);

                MySqlDataAdapter da = new MySqlDataAdapter(display_sugestao);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewSugestao.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            con.Close();
        }

        private void bNRepondidos_Click(object sender, EventArgs e)
        {
            bAceitos.BackColor = Color.FromArgb(240, 240, 240);
            bRecusados.BackColor = Color.FromArgb(240, 240, 240);
            bNRepondidos.BackColor = Color.Silver;

            dataGridViewSugestao.AutoGenerateColumns = false;

            dataGridViewSugestao.Columns["Column1"].DisplayIndex = 0;
            dataGridViewSugestao.Columns["Column2"].DisplayIndex = 1;
            dataGridViewSugestao.Columns["Column3"].DisplayIndex = 2;
            dataGridViewSugestao.Columns["Column5"].DisplayIndex = 3;
            dataGridViewSugestao.Columns["Column6"].DisplayIndex = 4;
            dataGridViewSugestao.Columns["Column5"].Visible = true;
            dataGridViewSugestao.Columns["Column6"].Visible = true;

            try
            {
                con.Open();
                MySqlCommand display_sugestao = new MySqlCommand("select idsuggestion, idcategory, dessuggestion,dtrequest,descategory from tb_servicesuggestions inner join tb_categories using(idcategory) where tb_servicesuggestions.idcategory = tb_categories.idcategory and tb_servicesuggestions.situation = 0;", con);

                MySqlDataAdapter da = new MySqlDataAdapter(display_sugestao);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewSugestao.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            con.Close();
        }

        private void bRecusados_Click(object sender, EventArgs e)
        {
            bAceitos.BackColor = Color.FromArgb(240, 240, 240);
            bRecusados.BackColor = Color.Silver;
            bNRepondidos.BackColor = Color.FromArgb(240, 240, 240);

            dataGridViewSugestao.AutoGenerateColumns = false;

            dataGridViewSugestao.Columns["Column1"].DisplayIndex = 0;
            dataGridViewSugestao.Columns["Column2"].DisplayIndex = 1;
            dataGridViewSugestao.Columns["Column3"].DisplayIndex = 2;
            dataGridViewSugestao.Columns["Column5"].DisplayIndex = 3;
            dataGridViewSugestao.Columns["Column6"].DisplayIndex = 4;
            dataGridViewSugestao.Columns["Column5"].Visible = false;
            dataGridViewSugestao.Columns["Column6"].Visible = false;

            try
            {
                con.Open();
                MySqlCommand display_sugestao = new MySqlCommand("select idsuggestion, idcategory, dessuggestion,dtrequest,descategory from tb_servicesuggestions inner join tb_categories using(idcategory) where tb_servicesuggestions.idcategory = tb_categories.idcategory and tb_servicesuggestions.situation = 2;", con);

                MySqlDataAdapter da = new MySqlDataAdapter(display_sugestao);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewSugestao.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            con.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                MySqlCommand inserirservico = new MySqlCommand("insert into tb_services(desservice, idcategory) values('" + richTextBoxNomeServ.Text + "','" + idcategoria + "');", con);
                inserirservico.ExecuteNonQuery();

                MessageBox.Show("Serviço cadastrado.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão\nErro: " + ex.Message + "\n" + ex.ToString());
            }
            con.Close();

            panelAceitarServico.Visible = false;

            button2_Click(sender, e);
        }

        private void richTextBoxNomeServ_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                try
            {
                con.Open();
                MySqlCommand inserirservico = new MySqlCommand("insert into tb_services(desservice, idcategory) values('" + richTextBoxNomeServ.Text + "','" + idcategoria + "');", con);
                inserirservico.ExecuteNonQuery();

                MessageBox.Show("Serviço cadastrado.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão\nErro: " + ex.Message + "\n" + ex.ToString());
            }
                con.Close();
                panelAceitarServico.Visible = false;
                button2_Click(sender, e);
            }
        }
    }
}
