﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace ToolBoxAdmin
{
    public partial class Form3 : Form
    {
        MySqlConnection con;
        Thread nt;
        public Form3()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            try
            {
                con = new MySqlConnection("server=143.106.241.3;port=3306;UserID=cl19248;database=cl19248;password=cl19248");
            }
            catch
            {
                MessageBox.Show("Falha na conexão");
            }
        }

        #region buttons home
        private void bHome_Click(object sender, EventArgs e)
        {
            if (panelBgeral.Visible == false)
            {
                this.bHome.BackColor = System.Drawing.Color.AliceBlue;
                panelBgeral.Visible = true;
            }
            else
            {
                this.bHome.BackColor = System.Drawing.Color.White;
                panelBgeral.Visible = false;
            }
        }

        private void bpedidos_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Sugestao);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bCadastrarServico_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Home);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bServicos_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Servicos);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bOrcamento_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(CadastrarServico);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bSair_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Sair);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void Sair()
        {
            Application.Run(new Form1());
        }

        private void CadastrarServico()
        {
            Application.Run(new Form4());
        }

        private void Servicos()
        {
            Application.Run(new Form3());
        }

        private void Home()
        {
            Application.Run(new Form2());
        }

        private void Sugestao()
        {
            Application.Run(new Form5());
        }
        #endregion

        private void Form3_Load(object sender, EventArgs e)
        {
            dataGridViewServicos.Location = new Point((this.Size.Width / 2 - dataGridViewServicos.Size.Width / 2)-200,40);
            dataGridViewServicos.Anchor = AnchorStyles.None;
            panelBgeral.Visible = false;

            DisplayService();
        }

        private void dataGridViewServicos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 4)
            {
                DialogResult ask_forDeletion = MessageBox.Show("Tem certeza que deseja deletar esse serviço?", "Sistema - ATENÇÃO", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult.Yes == ask_forDeletion)
                {
                    int d = int.Parse(dataGridViewServicos.Rows[e.RowIndex].Cells[0].Value.ToString());
                    deleteServico(d);
                    DisplayService();
                }
            }
            
        }

        private void bPesquisar_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                MySqlCommand display_servico = new MySqlCommand("select idservice, idcategory, desservice, descategory from tb_services inner join tb_categories using(idcategory) where tb_services.idcategory = tb_categories.idcategory and tb_services.desservice LIKE '%" + textBoxPesquisar.Text + "%' or tb_categories.descategory LIKE '%" + textBoxPesquisar.Text + "%';", con);

                MySqlDataAdapter da = new MySqlDataAdapter(display_servico);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewServicos.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            con.Close();
        }

        private void textBoxPesquisar_TextChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                MySqlCommand display_servico = new MySqlCommand("select idservice, idcategory, desservice, descategory from tb_services inner join tb_categories using(idcategory) where tb_services.idcategory = tb_categories.idcategory and tb_services.desservice LIKE '%" + textBoxPesquisar.Text + "%' or tb_categories.descategory LIKE '%" + textBoxPesquisar.Text + "%';", con);

                MySqlDataAdapter da = new MySqlDataAdapter(display_servico);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewServicos.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            con.Close();
        }

        private void deleteServico(int idservice)
        {
            //int cont = 0;
            //try
            //{
            //    con.Open();
            //    MySqlCommand Count = new MySqlCommand("select COUNT(idquote) from tb_quotes inner join tb_servicesprovider using(idservice,idprovider) where tb_quotes.idprovider = tb_servicesprovider.idprovider and tb_quotes.idservice = tb_servicesprovider.idservice and tb_quotes.idstatus != 8 and tb_quotes.idservice = " + idservice + "; ", con);
            //    MySqlDataReader resultado = Count.ExecuteReader();

            //    if (resultado.Read())
            //    {
            //        if (resultado["idquote"].ToString() != null || resultado["idquote"].ToString() != "")
            //            cont = int.Parse(resultado["idquote"].ToString());
            //        else
            //            cont = 0;
            //    }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            //}
            //con.Close();

            //if (cont == 0)
            //{
                try
                {
                    con.Open();
                    MySqlCommand deletar_servico = new MySqlCommand("delete from tb_services where idservice = '" + idservice + "';", con);
                    deletar_servico.ExecuteNonQuery();
                    MessageBox.Show("Serviço deletado.");
                }
                catch (Exception ex)
                {
                    if ("Cannot delete or update a parent row: a foreign key constraint fails (`cl19248`.`tb_servicesprovider`, CONSTRAINT `fk_servico_has_empresa_servico1` FOREIGN KEY (`idservice`) REFERENCES `tb_services` (`idservice`) ON DELETE NO ACTION ON UPDATE NO ACTION)" == ex.Message)
                        MessageBox.Show("Não é possível deletar esse serviço devido algum prestador tê-lo cadastrado, já.");
                    else
                        MessageBox.Show("Falha na conexão\nErro: " + ex.Message + "\n" + ex.ToString());
                }
                con.Close();
            //}
            //else
            //{
            //    MessageBox.Show("Não é possível deletar o serviço devido existir orçamentos ou pedidos não concluídos");
            //}

        }

        private void DisplayService()
        {
            dataGridViewServicos.AutoGenerateColumns = false;
            dataGridViewServicos.Columns["Column1"].DisplayIndex = 0;
            dataGridViewServicos.Columns["Column2"].DisplayIndex = 1;
            dataGridViewServicos.Columns["Column3"].DisplayIndex = 2;
            try
            {
                con.Open();
                MySqlCommand display_servico = new MySqlCommand("select idservice, idcategory, desservice, descategory from tb_services inner join tb_categories using(idcategory) where tb_services.idcategory = tb_categories.idcategory ;", con);

                MySqlDataAdapter da = new MySqlDataAdapter(display_servico);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewServicos.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DisplayService();
        }
    }
}
