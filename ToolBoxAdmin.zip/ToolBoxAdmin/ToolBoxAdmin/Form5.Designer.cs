﻿namespace ToolBoxAdmin
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form5));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panelSideMenu = new System.Windows.Forms.Panel();
            this.panelButtons = new System.Windows.Forms.Panel();
            this.bpedidos = new System.Windows.Forms.Button();
            this.panelBgeral = new System.Windows.Forms.Panel();
            this.bOrcamento = new System.Windows.Forms.Button();
            this.bServicos = new System.Windows.Forms.Button();
            this.bCadastrarServico = new System.Windows.Forms.Button();
            this.bHome = new System.Windows.Forms.Button();
            this.bSair = new System.Windows.Forms.Button();
            this.panelBemVindo = new System.Windows.Forms.Panel();
            this.labelWelcome = new System.Windows.Forms.Label();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dataGridViewSugestao = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.textBoxPesquisar = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.bPesquisar = new System.Windows.Forms.Button();
            this.bRecusados = new System.Windows.Forms.Button();
            this.bAceitos = new System.Windows.Forms.Button();
            this.bNRepondidos = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.richTextBoxNomeServ = new System.Windows.Forms.RichTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panelAceitarServico = new System.Windows.Forms.Panel();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.panelSideMenu.SuspendLayout();
            this.panelButtons.SuspendLayout();
            this.panelBgeral.SuspendLayout();
            this.panelBemVindo.SuspendLayout();
            this.panelLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSugestao)).BeginInit();
            this.panel1.SuspendLayout();
            this.panelAceitarServico.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelSideMenu
            // 
            this.panelSideMenu.BackColor = System.Drawing.Color.White;
            this.panelSideMenu.Controls.Add(this.panelButtons);
            this.panelSideMenu.Controls.Add(this.bSair);
            this.panelSideMenu.Controls.Add(this.panelBemVindo);
            this.panelSideMenu.Controls.Add(this.panelLogo);
            this.panelSideMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSideMenu.Location = new System.Drawing.Point(0, 0);
            this.panelSideMenu.Name = "panelSideMenu";
            this.panelSideMenu.Size = new System.Drawing.Size(280, 681);
            this.panelSideMenu.TabIndex = 7;
            // 
            // panelButtons
            // 
            this.panelButtons.BackColor = System.Drawing.Color.White;
            this.panelButtons.Controls.Add(this.bpedidos);
            this.panelButtons.Controls.Add(this.panelBgeral);
            this.panelButtons.Controls.Add(this.bHome);
            this.panelButtons.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelButtons.Location = new System.Drawing.Point(0, 151);
            this.panelButtons.Name = "panelButtons";
            this.panelButtons.Size = new System.Drawing.Size(280, 501);
            this.panelButtons.TabIndex = 13;
            // 
            // bpedidos
            // 
            this.bpedidos.Dock = System.Windows.Forms.DockStyle.Top;
            this.bpedidos.FlatAppearance.BorderSize = 0;
            this.bpedidos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bpedidos.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bpedidos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bpedidos.Image = ((System.Drawing.Image)(resources.GetObject("bpedidos.Image")));
            this.bpedidos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bpedidos.Location = new System.Drawing.Point(0, 160);
            this.bpedidos.Name = "bpedidos";
            this.bpedidos.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bpedidos.Size = new System.Drawing.Size(280, 40);
            this.bpedidos.TabIndex = 8;
            this.bpedidos.Text = "  sugestões";
            this.bpedidos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bpedidos.UseVisualStyleBackColor = true;
            this.bpedidos.Click += new System.EventHandler(this.bpedidos_Click);
            // 
            // panelBgeral
            // 
            this.panelBgeral.Controls.Add(this.bOrcamento);
            this.panelBgeral.Controls.Add(this.bServicos);
            this.panelBgeral.Controls.Add(this.bCadastrarServico);
            this.panelBgeral.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelBgeral.Location = new System.Drawing.Point(0, 40);
            this.panelBgeral.Name = "panelBgeral";
            this.panelBgeral.Size = new System.Drawing.Size(280, 120);
            this.panelBgeral.TabIndex = 7;
            // 
            // bOrcamento
            // 
            this.bOrcamento.Dock = System.Windows.Forms.DockStyle.Top;
            this.bOrcamento.FlatAppearance.BorderSize = 0;
            this.bOrcamento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bOrcamento.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bOrcamento.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bOrcamento.Image = ((System.Drawing.Image)(resources.GetObject("bOrcamento.Image")));
            this.bOrcamento.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bOrcamento.Location = new System.Drawing.Point(0, 80);
            this.bOrcamento.Name = "bOrcamento";
            this.bOrcamento.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.bOrcamento.Size = new System.Drawing.Size(280, 40);
            this.bOrcamento.TabIndex = 4;
            this.bOrcamento.Text = "  cadastrar novo serviço";
            this.bOrcamento.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bOrcamento.UseVisualStyleBackColor = true;
            this.bOrcamento.Click += new System.EventHandler(this.bOrcamento_Click);
            // 
            // bServicos
            // 
            this.bServicos.Dock = System.Windows.Forms.DockStyle.Top;
            this.bServicos.FlatAppearance.BorderSize = 0;
            this.bServicos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bServicos.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bServicos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bServicos.Image = ((System.Drawing.Image)(resources.GetObject("bServicos.Image")));
            this.bServicos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bServicos.Location = new System.Drawing.Point(0, 40);
            this.bServicos.Name = "bServicos";
            this.bServicos.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.bServicos.Size = new System.Drawing.Size(280, 40);
            this.bServicos.TabIndex = 7;
            this.bServicos.Text = "  serviços";
            this.bServicos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bServicos.UseVisualStyleBackColor = true;
            this.bServicos.Click += new System.EventHandler(this.bServicos_Click);
            // 
            // bCadastrarServico
            // 
            this.bCadastrarServico.Dock = System.Windows.Forms.DockStyle.Top;
            this.bCadastrarServico.FlatAppearance.BorderSize = 0;
            this.bCadastrarServico.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bCadastrarServico.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bCadastrarServico.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bCadastrarServico.Image = ((System.Drawing.Image)(resources.GetObject("bCadastrarServico.Image")));
            this.bCadastrarServico.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bCadastrarServico.Location = new System.Drawing.Point(0, 0);
            this.bCadastrarServico.Name = "bCadastrarServico";
            this.bCadastrarServico.Padding = new System.Windows.Forms.Padding(30, 0, 0, 0);
            this.bCadastrarServico.Size = new System.Drawing.Size(280, 40);
            this.bCadastrarServico.TabIndex = 2;
            this.bCadastrarServico.Text = "  home";
            this.bCadastrarServico.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bCadastrarServico.UseVisualStyleBackColor = true;
            this.bCadastrarServico.Click += new System.EventHandler(this.bCadastrarServico_Click);
            // 
            // bHome
            // 
            this.bHome.BackColor = System.Drawing.Color.Transparent;
            this.bHome.Dock = System.Windows.Forms.DockStyle.Top;
            this.bHome.FlatAppearance.BorderSize = 0;
            this.bHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bHome.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.bHome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bHome.Image = ((System.Drawing.Image)(resources.GetObject("bHome.Image")));
            this.bHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bHome.Location = new System.Drawing.Point(0, 0);
            this.bHome.Name = "bHome";
            this.bHome.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.bHome.Size = new System.Drawing.Size(280, 40);
            this.bHome.TabIndex = 6;
            this.bHome.Text = "  geral";
            this.bHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bHome.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bHome.UseVisualStyleBackColor = false;
            this.bHome.Click += new System.EventHandler(this.bHome_Click);
            // 
            // bSair
            // 
            this.bSair.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bSair.FlatAppearance.BorderSize = 0;
            this.bSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bSair.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bSair.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.bSair.Location = new System.Drawing.Point(0, 652);
            this.bSair.Name = "bSair";
            this.bSair.Size = new System.Drawing.Size(280, 29);
            this.bSair.TabIndex = 6;
            this.bSair.Text = "sair";
            this.bSair.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.bSair.UseVisualStyleBackColor = true;
            this.bSair.Click += new System.EventHandler(this.bSair_Click);
            // 
            // panelBemVindo
            // 
            this.panelBemVindo.Controls.Add(this.labelWelcome);
            this.panelBemVindo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelBemVindo.Location = new System.Drawing.Point(0, 86);
            this.panelBemVindo.Name = "panelBemVindo";
            this.panelBemVindo.Size = new System.Drawing.Size(280, 65);
            this.panelBemVindo.TabIndex = 1;
            // 
            // labelWelcome
            // 
            this.labelWelcome.AutoSize = true;
            this.labelWelcome.BackColor = System.Drawing.Color.Transparent;
            this.labelWelcome.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.labelWelcome.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.labelWelcome.Location = new System.Drawing.Point(12, 22);
            this.labelWelcome.Name = "labelWelcome";
            this.labelWelcome.Size = new System.Drawing.Size(67, 25);
            this.labelWelcome.TabIndex = 1;
            this.labelWelcome.Text = "Admin";
            this.labelWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelLogo
            // 
            this.panelLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panelLogo.Controls.Add(this.pictureBoxLogo);
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Padding = new System.Windows.Forms.Padding(2, 0, 0, 0);
            this.panelLogo.Size = new System.Drawing.Size(280, 86);
            this.panelLogo.TabIndex = 0;
            // 
            // pictureBoxLogo
            // 
            this.pictureBoxLogo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBoxLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBoxLogo.ErrorImage = null;
            this.pictureBoxLogo.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxLogo.Image")));
            this.pictureBoxLogo.InitialImage = null;
            this.pictureBoxLogo.Location = new System.Drawing.Point(0, 5);
            this.pictureBoxLogo.Name = "pictureBoxLogo";
            this.pictureBoxLogo.Size = new System.Drawing.Size(280, 86);
            this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxLogo.TabIndex = 0;
            this.pictureBoxLogo.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(280, 100);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1312, 581);
            this.panel2.TabIndex = 11;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.panelAceitarServico);
            this.panel3.Controls.Add(this.dataGridViewSugestao);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1312, 581);
            this.panel3.TabIndex = 3;
            // 
            // dataGridViewSugestao
            // 
            this.dataGridViewSugestao.AllowUserToAddRows = false;
            this.dataGridViewSugestao.AllowUserToDeleteRows = false;
            this.dataGridViewSugestao.AllowUserToResizeColumns = false;
            this.dataGridViewSugestao.AllowUserToResizeRows = false;
            this.dataGridViewSugestao.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.dataGridViewSugestao.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewSugestao.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewSugestao.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.dataGridViewSugestao.ColumnHeadersHeight = 34;
            this.dataGridViewSugestao.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridViewSugestao.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column4,
            this.Column7,
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column8,
            this.Column5,
            this.Column6});
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewSugestao.DefaultCellStyle = dataGridViewCellStyle20;
            this.dataGridViewSugestao.GridColor = System.Drawing.Color.White;
            this.dataGridViewSugestao.Location = new System.Drawing.Point(38, 51);
            this.dataGridViewSugestao.MultiSelect = false;
            this.dataGridViewSugestao.Name = "dataGridViewSugestao";
            this.dataGridViewSugestao.ReadOnly = true;
            this.dataGridViewSugestao.RowHeadersVisible = false;
            this.dataGridViewSugestao.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridViewSugestao.RowTemplate.Height = 30;
            this.dataGridViewSugestao.ShowEditingIcon = false;
            this.dataGridViewSugestao.Size = new System.Drawing.Size(1064, 488);
            this.dataGridViewSugestao.TabIndex = 0;
            this.dataGridViewSugestao.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewSugestao_CellClick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(247)))), ((int)(((byte)(251)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.bNRepondidos);
            this.panel1.Controls.Add(this.bAceitos);
            this.panel1.Controls.Add(this.bRecusados);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.textBoxPesquisar);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.bPesquisar);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(280, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1312, 100);
            this.panel1.TabIndex = 10;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Silver;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(349, 50);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(32, 32);
            this.button1.TabIndex = 44;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBoxPesquisar
            // 
            this.textBoxPesquisar.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxPesquisar.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.textBoxPesquisar.Location = new System.Drawing.Point(38, 50);
            this.textBoxPesquisar.Name = "textBoxPesquisar";
            this.textBoxPesquisar.Size = new System.Drawing.Size(267, 32);
            this.textBoxPesquisar.TabIndex = 1;
            this.textBoxPesquisar.TextChanged += new System.EventHandler(this.textBoxPesquisar_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label2.Location = new System.Drawing.Point(33, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Pesquise";
            // 
            // bPesquisar
            // 
            this.bPesquisar.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.bPesquisar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bPesquisar.Image = ((System.Drawing.Image)(resources.GetObject("bPesquisar.Image")));
            this.bPesquisar.Location = new System.Drawing.Point(311, 50);
            this.bPesquisar.Name = "bPesquisar";
            this.bPesquisar.Size = new System.Drawing.Size(32, 32);
            this.bPesquisar.TabIndex = 2;
            this.bPesquisar.UseVisualStyleBackColor = false;
            this.bPesquisar.Click += new System.EventHandler(this.bPesquisar_Click);
            // 
            // bRecusados
            // 
            this.bRecusados.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.bRecusados.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bRecusados.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bRecusados.Location = new System.Drawing.Point(539, 50);
            this.bRecusados.Name = "bRecusados";
            this.bRecusados.Size = new System.Drawing.Size(146, 32);
            this.bRecusados.TabIndex = 45;
            this.bRecusados.Text = "Recusadas";
            this.bRecusados.UseVisualStyleBackColor = false;
            this.bRecusados.Click += new System.EventHandler(this.bRecusados_Click);
            // 
            // bAceitos
            // 
            this.bAceitos.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.bAceitos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bAceitos.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bAceitos.Location = new System.Drawing.Point(387, 50);
            this.bAceitos.Name = "bAceitos";
            this.bAceitos.Size = new System.Drawing.Size(146, 32);
            this.bAceitos.TabIndex = 46;
            this.bAceitos.Text = "Aceitas";
            this.bAceitos.UseVisualStyleBackColor = false;
            this.bAceitos.Click += new System.EventHandler(this.button2_Click);
            // 
            // bNRepondidos
            // 
            this.bNRepondidos.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.bNRepondidos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bNRepondidos.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.bNRepondidos.Location = new System.Drawing.Point(691, 50);
            this.bNRepondidos.Name = "bNRepondidos";
            this.bNRepondidos.Size = new System.Drawing.Size(146, 32);
            this.bNRepondidos.TabIndex = 47;
            this.bNRepondidos.Text = "Não respondidas";
            this.bNRepondidos.UseVisualStyleBackColor = false;
            this.bNRepondidos.Click += new System.EventHandler(this.bNRepondidos_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(131)))), ((int)(((byte)(238)))));
            this.button3.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(23, 152);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(280, 48);
            this.button3.TabIndex = 142;
            this.button3.Text = "Cadastrar serviço";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // richTextBoxNomeServ
            // 
            this.richTextBoxNomeServ.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.richTextBoxNomeServ.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBoxNomeServ.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.richTextBoxNomeServ.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.richTextBoxNomeServ.Location = new System.Drawing.Point(23, 48);
            this.richTextBoxNomeServ.MaxLength = 256;
            this.richTextBoxNomeServ.Name = "richTextBoxNomeServ";
            this.richTextBoxNomeServ.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.richTextBoxNomeServ.Size = new System.Drawing.Size(280, 98);
            this.richTextBoxNomeServ.TabIndex = 141;
            this.richTextBoxNomeServ.Text = "";
            this.richTextBoxNomeServ.KeyDown += new System.Windows.Forms.KeyEventHandler(this.richTextBoxNomeServ_KeyDown);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.label4.Location = new System.Drawing.Point(18, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(151, 25);
            this.label4.TabIndex = 140;
            this.label4.Text = "nome do serviço";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelAceitarServico
            // 
            this.panelAceitarServico.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(247)))), ((int)(((byte)(251)))));
            this.panelAceitarServico.Controls.Add(this.button3);
            this.panelAceitarServico.Controls.Add(this.label4);
            this.panelAceitarServico.Controls.Add(this.richTextBoxNomeServ);
            this.panelAceitarServico.Location = new System.Drawing.Point(1108, 51);
            this.panelAceitarServico.Name = "panelAceitarServico";
            this.panelAceitarServico.Size = new System.Drawing.Size(322, 231);
            this.panelAceitarServico.TabIndex = 1;
            this.panelAceitarServico.Visible = false;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "idsuggestion";
            this.Column4.HeaderText = "#idsuggestion";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Visible = false;
            // 
            // Column7
            // 
            this.Column7.DataPropertyName = "idcategory";
            this.Column7.HeaderText = "#idcategory";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Visible = false;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "descategory";
            this.Column1.HeaderText = "Categoria";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 300;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "dessuggestion";
            this.Column2.HeaderText = "Serviço";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 300;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "dtrequest";
            this.Column3.HeaderText = "Data";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 200;
            // 
            // Column8
            // 
            this.Column8.DataPropertyName = "situation";
            this.Column8.HeaderText = "situation";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.Visible = false;
            // 
            // Column5
            // 
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            dataGridViewCellStyle18.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.Color.Green;
            this.Column5.DefaultCellStyle = dataGridViewCellStyle18;
            this.Column5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Column5.HeaderText = "";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Text = "Aceitar";
            this.Column5.UseColumnTextForButtonValue = true;
            this.Column5.Width = 130;
            // 
            // Column6
            // 
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.Red;
            dataGridViewCellStyle19.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Column6.DefaultCellStyle = dataGridViewCellStyle19;
            this.Column6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Column6.HeaderText = "";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Text = "Recusar";
            this.Column6.UseColumnTextForButtonValue = true;
            this.Column6.Width = 130;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.label1.Location = new System.Drawing.Point(382, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 25);
            this.label1.TabIndex = 48;
            this.label1.Text = "Sugestões:";
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1592, 681);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelSideMenu);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form5";
            this.Text = "Sugestões";
            this.Load += new System.EventHandler(this.Form5_Load);
            this.panelSideMenu.ResumeLayout(false);
            this.panelButtons.ResumeLayout(false);
            this.panelBgeral.ResumeLayout(false);
            this.panelBemVindo.ResumeLayout(false);
            this.panelBemVindo.PerformLayout();
            this.panelLogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSugestao)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelAceitarServico.ResumeLayout(false);
            this.panelAceitarServico.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelSideMenu;
        private System.Windows.Forms.Panel panelButtons;
        private System.Windows.Forms.Button bSair;
        private System.Windows.Forms.Panel panelBemVindo;
        private System.Windows.Forms.Label labelWelcome;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.PictureBox pictureBoxLogo;
        private System.Windows.Forms.Button bpedidos;
        private System.Windows.Forms.Panel panelBgeral;
        private System.Windows.Forms.Button bOrcamento;
        private System.Windows.Forms.Button bServicos;
        private System.Windows.Forms.Button bCadastrarServico;
        private System.Windows.Forms.Button bHome;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dataGridViewSugestao;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBoxPesquisar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button bPesquisar;
        private System.Windows.Forms.Button bNRepondidos;
        private System.Windows.Forms.Button bAceitos;
        private System.Windows.Forms.Button bRecusados;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.RichTextBox richTextBoxNomeServ;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panelAceitarServico;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewButtonColumn Column5;
        private System.Windows.Forms.DataGridViewButtonColumn Column6;
        private System.Windows.Forms.Label label1;
    }
}