﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace ToolBoxAdmin
{
    public partial class Form3 : Form
    {
        MySqlConnection con;
        Thread nt;
        public Form3()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
            try
            {
                con = new MySqlConnection("server=143.106.241.3;port=3306;UserID=cl19248;database=cl19248;password=cl19248");
            }
            catch
            {
                MessageBox.Show("Falha na conexão");
            }
        }

        #region buttons home
        private void bHome_Click(object sender, EventArgs e)
        {
            if (panelBgeral.Visible == false)
            {
                this.bHome.BackColor = System.Drawing.Color.AliceBlue;
                panelBgeral.Visible = true;
            }
            else
            {
                this.bHome.BackColor = System.Drawing.Color.White;
                panelBgeral.Visible = false;
            }
        }

        private void bpedidos_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Sugestao);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bCadastrarServico_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Home);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bServicos_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Servicos);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bOrcamento_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(CadastrarServico);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void bSair_Click(object sender, EventArgs e)
        {
            this.Close();
            nt = new Thread(Sair);
            nt.SetApartmentState(ApartmentState.STA);
            nt.Start();
        }

        private void Sair()
        {
            Application.Run(new Form1());
        }

        private void CadastrarServico()
        {
            Application.Run(new Form4());
        }

        private void Servicos()
        {
            Application.Run(new Form3());
        }

        private void Home()
        {
            Application.Run(new Form2());
        }

        private void Sugestao()
        {
            Application.Run(new Form5());
        }
        #endregion

        private void Form3_Load(object sender, EventArgs e)
        {
            panelBgeral.Visible = false;

            DisplayService();
        }

        private void dataGridViewServicos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 4)
            {
                DialogResult ask_forDeletion = MessageBox.Show("Tem certeza que deseja deletar esse serviço?", "Sistema - ATENÇÃO", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (DialogResult.Yes == ask_forDeletion)
                {
                    int d = int.Parse(dataGridViewServicos.Rows[e.RowIndex].Cells[0].Value.ToString());
                    deleteServico(d);
                    DisplayService();
                }
            }
            
        }

        private void bPesquisar_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                MySqlCommand display_servico = new MySqlCommand("select idservice, idcategory, desservice, descategory from tb_services inner join tb_categories using(idcategory) where tb_services.idcategory = tb_categories.idcategory and tb_services.desservice LIKE '%" + textBoxPesquisar.Text + "%' or tb_categories.descategory LIKE '%" + textBoxPesquisar.Text + "%';", con);

                MySqlDataAdapter da = new MySqlDataAdapter(display_servico);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewServicos.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally
            {
                con.Close();
            }
        }

        private void textBoxPesquisar_TextChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                MySqlCommand display_servico = new MySqlCommand("select idservice, idcategory, desservice, descategory from tb_services inner join tb_categories using(idcategory) where tb_services.idcategory = tb_categories.idcategory and tb_services.desservice LIKE '%" + textBoxPesquisar.Text + "%' or tb_categories.descategory LIKE '%" + textBoxPesquisar.Text + "%';", con);

                MySqlDataAdapter da = new MySqlDataAdapter(display_servico);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewServicos.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            con.Close();
        }

        private void deleteServico(int idservice)
        {
                try
                {
                    con.Open();
                    MySqlCommand deletar_servico = new MySqlCommand("delete from tb_services where idservice = '" + idservice + "';", con);
                    deletar_servico.ExecuteNonQuery();
                    MessageBox.Show("Serviço deletado.");
                }
                catch (Exception ex)
                {
                    if ("Cannot delete or update a parent row: a foreign key constraint fails (`cl19248`.`tb_servicesprovider`, CONSTRAINT `fk_servico_has_empresa_servico1` FOREIGN KEY (`idservice`) REFERENCES `tb_services` (`idservice`) ON DELETE NO ACTION ON UPDATE NO ACTION)" == ex.Message)
                        MessageBox.Show("Não é possível deletar esse serviço devido algum prestador tê-lo cadastrado, já.");
                    else
                        MessageBox.Show("Falha na conexão\nErro: " + ex.Message + "\n" + ex.ToString());
                }
                finally
                {
                    con.Close();
                }

        }

        private void DisplayService()
        {
            dataGridViewServicos.AutoGenerateColumns = false;
            dataGridViewServicos.Columns["Column1"].DisplayIndex = 0;
            dataGridViewServicos.Columns["Column2"].DisplayIndex = 1;
            dataGridViewServicos.Columns["Column3"].DisplayIndex = 2;
            try
            {
                con.Open();
                MySqlCommand display_servico = new MySqlCommand("select idservice, idcategory, desservice, descategory from tb_services inner join tb_categories using(idcategory) where tb_services.idcategory = tb_categories.idcategory ;", con);

                MySqlDataAdapter da = new MySqlDataAdapter(display_servico);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridViewServicos.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Falha na conexão. Tente novamente." + "\n\n" + ex.Message + "\n\n" + ex.ToString(), "Tente novamente", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally
            {
                con.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DisplayService();
        }

        GraphicsPath GetRoundPath(RectangleF Rect, int radius)
        {
            float r2 = radius / 2f;
            GraphicsPath GraphPath = new GraphicsPath();

            GraphPath.AddArc(Rect.X, Rect.Y, radius, radius, 180, 90);
            GraphPath.AddLine(Rect.X + r2, Rect.Y, Rect.Width - r2, Rect.Y);
            GraphPath.AddArc(Rect.X + Rect.Width - radius, Rect.Y, radius, radius, 270, 90);
            GraphPath.AddLine(Rect.Width, Rect.Y + r2, Rect.Width, Rect.Height - r2);
            GraphPath.AddArc(Rect.X + Rect.Width - radius,
                             Rect.Y + Rect.Height - radius, radius, radius, 0, 90);
            GraphPath.AddLine(Rect.Width - r2, Rect.Height, Rect.X + r2, Rect.Height);
            GraphPath.AddArc(Rect.X, Rect.Y + Rect.Height - radius, radius, radius, 90, 90);
            GraphPath.AddLine(Rect.X, Rect.Height - r2, Rect.X, Rect.Y + r2);

            GraphPath.CloseFigure();
            return GraphPath;
        }

        private void bPesquisar_Paint(object sender, PaintEventArgs e)
        {
            base.OnPaint(e);
            RectangleF Rect = new RectangleF(0, 0, bPesquisar.Width, bPesquisar.Height);
            GraphicsPath GraphPath = GetRoundPath(Rect, 10);

            bPesquisar.Region = new Region(GraphPath);
            using (System.Drawing.Pen pen = new System.Drawing.Pen(System.Drawing.Color.Transparent, 1.75f))
            {
                pen.Alignment = PenAlignment.Inset;
                e.Graphics.DrawPath(pen, GraphPath);
            }
        }

        private void button1_Paint(object sender, PaintEventArgs e)
        {
            base.OnPaint(e);
            RectangleF Rect = new RectangleF(0, 0, button1.Width, button1.Height);
            GraphicsPath GraphPath = GetRoundPath(Rect, 10);

            button1.Region = new Region(GraphPath);
            using (System.Drawing.Pen pen = new System.Drawing.Pen(System.Drawing.Color.Transparent, 1.75f))
            {
                pen.Alignment = PenAlignment.Inset;
                e.Graphics.DrawPath(pen, GraphPath);
            }
        }
    }
}
